import logo from './logo.svg';
import React, { useState, useEffect, Component } from 'react';
import './App.css';
import {BrowserRouter, Switch, Route, Link} from "react-router-dom";

class App extends Component {
      constructor() {
        super();
        this.state = {
        };
        this.onSubmitForm = this.onSubmitForm.bind(this);
        
      }
    
      handleSubmit = event => {
          event.preventDefault();
          const data = new FormData(event.target);
          console.log(data.get('one'))
          console.log(data.get('two'))
          fetch('/page2',{
              method: 'post',
              body: data,
          })
      };

      onSubmitForm() {
        console.log(this.state)
      }

      render() {
        const { items } = this.state;
          
  return (
    <div className="App">
       <header className="app-header">
        <BrowserRouter>
          <div>
            <Link className="App-link" to="/">Names</Link> | <Link className="App-link" to="/page2">Scoreboard</Link>
          </div>
          <Switch>
            <Route exact path="/">
            <form class="names" handleSubmit={this.handleSubmit}>

                <h5>Enter names</h5>
                <label>Player 1 name:
                  <input
                  type="text"
                  name="one"
                  placeholder="Name"
                  ref={input => this.name1 = input}/>
                </label>
                <p></p>

                <label>Player 2 name:
                 <input
                 type="text"
                 name="two"
                 placeholder="Name"
                 ref={input => this.name2 = input}/>
                </label>

                <p>Who will be serving?</p>

                <p></p>
                <button
                    type="submit">Save
                </button>
                
                </form>
          
          <button id="counter-plus1">{this.one}</button>
          <button id="counter-plus2">{this.two}</button>
          
          </Route>
          <Route path="/page2">
          <h1>Point Counter</h1>

          
          
          <h3 id="serving">N/A</h3>

          </Route>
        </Switch>
        </BrowserRouter>
      </header>
          
    </div>
  );
 }
    }

export default App;
