import logo from './logo.svg';
import React, { useState, useEffect, Component } from 'react';
import './App.css';
import {BrowserRouter, Switch, Route, Link} from "react-router-dom";
import ReactDOM from 'react-dom';

class Number extends React.Component {
  constructor(props) {
    super(props);
      this.state={
          number: 0
      };
      this.state={
          num: 0
      }
  }
  
  componentDidUpdate() {
    console.log('componentDidUpdate');
  }
  
  render() {
    if((this.props.number % 4 == 2|| this.props.number % 4 == 3)){
        return (
            <div>
                <h1>Player 2 is serving</h1>
            </div>
        );
    } else {
        return (
            <div>
                <h1>Player 1 is serving</h1>
            </div>
        );
    }
  }
}

class Winner extends React.Component {
  constructor(props) {
    super(props);
      this.state={
          number1: 0
      };
      this.state={
          number2: 0
      }
  }
    
    reset(){
      this.setState(
        {
          count:0,
          count2:0,
          tcount:0,
        }
      )
    }
  
  componentDidUpdate() {
    console.log('componentDidUpdate');
  }
  
  render() {
    if(this.props.number1>=11 && this.props.number1-this.props.number2>=2){
        this.state={
            number1: 0
        };
        this.state={
            number2: 0
        };
        this.state={
            win1: this.state.win1+1
        };
        return (
            <div>
                <h1>Player 1 has won!</h1>
            </div>
            
        );
    }
    if(this.props.number2>=11 && this.props.number2-this.props.number1>=2){
        return (
            <div>
                <h1>Player 2 has won!</h1>
            </div>
        );
    } else {
        return (
             <div>
                <h1></h1>
            </div>
        );
    }
  }
}

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = { count: 0 }
        this.state = { count2: 0 }
        this.state = { tcount: 0 }
        this.state = { color: 1 }
        this.state = { player1: '' }
        this.state = { player2: '' }
}
    mySubmitHandler = (event) => {
        event.preventDefault();
        let age = this.state.age;
      }
      myChangeHandler = (event) => {
        let nam = event.target.name;
        let val = event.target.value;
        this.setState({[nam]: val});
      }
    
    onRadioChange = (event) => {
        this.setState({
          color: event.target.value
        });
      }
    
    increment(){
       this.setState(
         {
           count:this.state.count+1,
           tcount:this.state.tcount+1
         }
       );
     };

    increment2(){
       this.setState(
         {
           count2:this.state.count2+1,
           tcount:this.state.tcount+1
         }
       );
     };

     reset(){
       this.setState(
         {
           count:0,
           count2:0,
           tcount:0,
         }
       )
     }
    
render() {
    return (
            <BrowserRouter>
              <div>
                <Link className="App-link" to="/">Names</Link> | <Link className="App-link" to="/page2">Scoreboard</Link>
              </div>
              <Switch>
                <Route exact path="/">
            <form onSubmit={this.mySubmitHandler}>
            <p>Player 1:</p>
            <input
            type='text'
            name="player1"
            onChange={this.myChangeHandler}
            />
            <p>Player 2:</p>
            <input
            type='text'
            name="player2"
            onChange={this.myChangeHandler}
            />
            <p>Who is serving?</p>
            <p></p><input type="radio" value="0" name="gender" onChange={this.onRadioChange} /> {this.state.player1}
            <p></p><input type="radio" value="1" name="gender" onChange={this.onRadioChange} /> {this.state.player2}
            <br/>
            <br/>
            <input
            type='submit'
            />
            </form>
            <p></p>
            <h1>Point Counter</h1>
            <div>
            <hr />
            <button className="reset" onClick={(e)=>this.reset(e)}>Start!</button>
            <Number number={this.state.tcount} color={this.state.color} />
            <h1>{this.state.player1} Score: {this.state.count}</h1>
                        <button className="inc"  onClick={(e)=>this.increment(e)}>Score Point!</button>
            <h1>{this.state.player2} Score: {this.state.count2}</h1>
                        <button className="inc2"  onClick={(e)=>this.increment2(e)}>Score Point!</button>
            <Winner number1={this.state.count} number2={this.state.count2} />

            <p></p>
            </div>

            </Route>
            <Route path="/page2">
            <h1>Point Counter</h1>

            
            
            <h3 id="serving">N/A</h3>

            </Route>
          </Switch>
          </BrowserRouter>

            );
    }
}


ReactDOM.render(<App />, document.getElementById('root'));
export default App;
