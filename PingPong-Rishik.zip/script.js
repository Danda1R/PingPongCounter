window.onload = function(){
  var button1 = document.getElementById("counter-plus1"),
  count1=0;
  var button2 = document.getElementById("counter-plus2"),
  count2=0;

  var server = document.getElementById("serving");

  var x="Steve";
  var y="Eric";
  var s=1;
  
  //Takes user input to insert names of players
  function sumbit(){
    x=document.getElementById("Player1").value;
    y=document.getElementById("Player2").value;
    s=document.getElementById("Players").value;
  }

  button1.innerHTML=x+": "+count1;
  button2.innerHTML=y+": "+count2;
  if(s==1){
    server.innerHTML=x+" is serving";
  }
  else{
    server.innerHTML=y+" is serving";
  }

  //If player 1 counter is pressed
  button1.onclick=function(){
    count1++;
    button1.innerHTML=x+": "+count1;
    //Every 2 rounds
    if((count1+count2)%2==0){
      //Switch servers
      if(s==2){
        s=1;
      }
      else{
        s=2;
      }
    }
    if(s==1){
      server.innerHTML=x+" is serving";
    }
    else{
      server.innerHTML=y+" is serving";
    }
    //If player 1 won
    if(count1>=11 && count1-count2>=2){
      server.innerHTML=x+" Wins With "+count1+" points";
      count1=0;
      count2=0;
      s=1;
      button1.innerHTML=x+": "+count1;
      button2.innerHTML=y+": "+count2;
    }
  }

  //If player 2 counter is pressed
  button2.onclick=function(){
    count2++;
    button2.innerHTML=y+": "+count2;
    //Every 2 rounds
    if((count1+count2)%2==0){
      //Switches servers
      if(s==2){
        s=1;
      }
      else{
        s=2;
      }
    }
    if(s==1){
      server.innerHTML=x+" is serving";
    }
    else{
      server.innerHTML=y+" is serving";
    }
    //If player 2 won
    if(count2>=11 && count2-count1>=2){
      server.innerHTML=y+" Wins With "+count2+" points";
      count1=0;
      count2=0;
      s=1;
      button1.innerHTML=x+": "+count1;
      button2.innerHTML=y+": "+count2;
    }
  }
}
